# put yours
API_ID = 123
API_HASH = "123"

# =============[upgrades]================
# default is 5 level you can change it your self
PAINT_REWARD_MAX = 5 # max is 7
ENERGY_LIMIT_MAX = 5 # max is 6
RE_CHARGE_SPEED_MAX = 5 # max is 11
X3_PIXEl = True # turn False if you wantt random
# ================[proxy]================
USE_PROXY = False # or put True if you want use it
PROXIE = "type://user:pass@ip:port" # you can remove user:pass@ if your proxy dont have user and password
# ================[timezone]================
TIMEZONE = "Asia/Tehran"  # Add this line for timezone
